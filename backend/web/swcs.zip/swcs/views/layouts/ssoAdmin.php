<ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
   <li class="sidebar-toggler-wrapper hide">
      <div class="sidebar-toggler">
         <span></span>
      </div>
   </li>
   <li class="nav-item start active open">
      <a href="<?=Yii::app()->createAbsoluteUrl('/admin');?>" class="nav-link nav-toggle">
      <i class="icon-home"></i>
      <span class="title">Dashboard</span>
      <span class="selected"></span>
      </a>
   </li>
</ul>
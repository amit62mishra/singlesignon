-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

USE `transfer`;

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `dept_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `department_name` varchar(512) NOT NULL,
  `department_unique_code` varchar(128) NOT NULL,
  `department_link` varchar(128) NOT NULL,
  `department_img` varchar(128) NOT NULL DEFAULT 'Seal_of_Chhattisgarh.png',
  `bank_scheme_code` varchar(50) DEFAULT NULL,
  `added_on` datetime NOT NULL,
  `dept_order` int(3) NOT NULL DEFAULT 10,
  `updated_on` date DEFAULT NULL,
  `is_department_active` int(11) NOT NULL DEFAULT 1,
  `is_sw_dept` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`dept_id`),
  UNIQUE KEY `department_unique_code` (`department_unique_code`),
  KEY `dept_id` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `mst_district`;
CREATE TABLE `mst_district` (
  `district_id` int(11) NOT NULL AUTO_INCREMENT,
  `district_name` varchar(255) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `is_active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `is_deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`district_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mst_roles`;
CREATE TABLE `mst_roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(255) NOT NULL,
  `is_active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `is_deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_on` datetime NOT NULL DEFAULT current_timestamp(),
  `default_action` varchar(100) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mst_user`;
CREATE TABLE `mst_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `user_full_name` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `auth_key` varchar(255) NOT NULL,
  `mobile_number` bigint(20) NOT NULL,
  `district_id` int(11) NOT NULL,
  `is_active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `is_deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_password_updated` enum('Y','N') NOT NULL DEFAULT 'N',
  `is_profile_updated` enum('Y','N') NOT NULL,
  `total_application` int(11) NOT NULL,
  `gender` varchar(2) NOT NULL,
  `office_location` varchar(50) NOT NULL,
  `aadhar` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`),
  UNIQUE KEY `email_id` (`email_id`),
  KEY `district_id` (`district_id`),
  CONSTRAINT `mst_user_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `mst_district` (`district_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `mst_user_role_mapping`;
CREATE TABLE `mst_user_role_mapping` (
  `map_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` enum('Y','N') NOT NULL DEFAULT 'Y',
  `is_deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `district_id` int(11) NOT NULL,
  `department_id` int(11) unsigned NOT NULL,
  `notification_no` varchar(100) NOT NULL,
  `notification_date` varchar(20) NOT NULL,
  `time_of_joining` varchar(100) NOT NULL,
  `date_of_joining` varchar(100) NOT NULL,
  `charge` varchar(100) NOT NULL,
  `old_dept` varchar(100) NOT NULL,
  `old_role` varchar(100) NOT NULL,
  `primary_user_id` int(11) NOT NULL,
  PRIMARY KEY (`map_id`),
  KEY `user_id` (`user_id`),
  KEY `role_id` (`role_id`),
  KEY `department_id` (`department_id`),
  CONSTRAINT `mst_user_role_mapping_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `mst_user` (`user_id`),
  CONSTRAINT `mst_user_role_mapping_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `mst_roles` (`role_id`),
  CONSTRAINT `mst_user_role_mapping_ibfk_3` FOREIGN KEY (`department_id`) REFERENCES `departments` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


SET NAMES utf8mb4;

DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(255) NOT NULL,
  `act_rule` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `service_model` varchar(255) NOT NULL,
  `department_id` int(11) NOT NULL,
  `integration_flag` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `abbreviation` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` int(11) NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `services` (`service_id`, `service_name`, `act_rule`, `website`, `service_model`, `department_id`, `integration_flag`, `category`, `abbreviation`, `created_at`, `updated_at`, `is_active`) VALUES
(2,	'NOC from fire department (prior to commencement )',	'',	'',	'',	1,	'',	'',	'',	'2020-07-14 03:25:20',	'2020-07-14 03:25:20',	0),
(3,	'All necessary procedures and checklist to be published on the portal?',	'',	'',	'',	1,	'',	'',	'',	'2020-07-14 03:25:20',	'2020-07-14 03:25:20',	0),
(4,	'Timeline for delivery of the service to be mandate through the public service delivery guarantee Act .?\r\n  \r\n',	'',	'',	'',	1,	'',	'',	'',	'2020-07-14 03:25:20',	'2020-07-14 03:25:20',	0),
(5,	'The procedures for application submission,payment or fee to be made online?',	'',	'',	'',	1,	'',	'',	'',	'2020-07-14 03:25:20',	'2020-07-14 03:25:20',	0),
(6,	'The Portal Should allow applicant to track the status of the application online',	'',	'',	'',	1,	'',	'',	'',	'2020-07-14 03:25:20',	'2020-07-14 03:25:20',	0),
(7,	'The applicant should be able to download final certificate from the portal',	'',	'',	'',	1,	'',	'',	'',	'2020-07-14 03:25:20',	'2020-07-14 03:25:20',	0),
(8,	'There should be no requirement of any physical touchpoint between the applicant and Department / Agency ',	'',	'',	'',	1,	'',	'',	'',	'2020-07-14 03:25:20',	'2020-07-14 03:25:20',	0),
(10,	'Testing Service\r\n',	'',	'',	'',	1,	'',	'',	'',	'2020-07-14 03:25:20',	'2020-07-14 03:25:20',	0)
ON DUPLICATE KEY UPDATE `service_id` = VALUES(`service_id`), `service_name` = VALUES(`service_name`), `act_rule` = VALUES(`act_rule`), `website` = VALUES(`website`), `service_model` = VALUES(`service_model`), `department_id` = VALUES(`department_id`), `integration_flag` = VALUES(`integration_flag`), `category` = VALUES(`category`), `abbreviation` = VALUES(`abbreviation`), `created_at` = VALUES(`created_at`), `updated_at` = VALUES(`updated_at`), `is_active` = VALUES(`is_active`);

DROP TABLE IF EXISTS `user_active_tokens`;
CREATE TABLE `user_active_tokens` (
  `token_id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(32) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `token_created_on` datetime NOT NULL,
  `token_accessed_on` datetime NOT NULL,
  `callback_url` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `user_role_access_mapping`;
CREATE TABLE `user_role_access_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `dept_id` int(11) unsigned NOT NULL,
  `is_active` varchar(1) NOT NULL,
  `url` varchar(200) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `role_id` (`role_id`),
  KEY `user_id` (`user_id`),
  KEY `dept_id` (`dept_id`),
  CONSTRAINT `user_role_access_mapping_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`),
  CONSTRAINT `user_role_access_mapping_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `mst_roles` (`role_id`),
  CONSTRAINT `user_role_access_mapping_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `mst_user` (`user_id`),
  CONSTRAINT `user_role_access_mapping_ibfk_4` FOREIGN KEY (`dept_id`) REFERENCES `departments` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 2020-09-28 06:28:25
